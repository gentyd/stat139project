library("GWmodel")
library("robustbase")
library('sp')
library('spgwr')
library('raster')
library('rgdal')
library('ggplot2')
library('sf')

houses = read.csv("/Users/gentydaku/Downloads/stat139project-master 2/DC_DATA.csv")

houses$Percent_Asian

# This line calculates the bandwidth for you by cross validation
# GWRbandwidth = gwr.sel(PRICE ~ Crime, data=houses, coords=cbind(houses$X,houses$Y), adapt=T)

# CHANGE PREDICTOR HERE 1/2
gwr.model = gwr(PRICE~Percent_Black, data = houses, coords = cbind(houses$X, houses$Y), bandwidth = 0.01315562)

results = as.data.frame(gwr.model$SDF)
 
# CHANGE PREDICTOR HERE 2/2
houses$data = gwr.model$SDF$Percent_Black

dc_shapefile = readOGR("/Users/gentydaku/Downloads/cb_2017_11_tract_500k/cb_2017_11_tract_500k.shp")
line = fortify(dc_shapefile)

ggplot(houses, aes(x=houses$X,y=houses$Y)) + geom_point(aes(colour=houses$data))+
  scale_colour_gradient2(low = "red", mid = "white", high = "blue", midpoint = 0, space = "rgb", na.value = "grey50",
                         guide = "colourbar", guide_legend(title="Coefs"))+coord_equal() +
  geom_polygon(data = dc_shapefile, aes(x = lat, y = long, group = group), colour = "black", fill = NA)
